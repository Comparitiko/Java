/*
  19. Escriba el valor ASCII de la 'J' y de la 'j' sin consultar la tabla.
 */

public class Ejercicio19 {
  
  public static void main(String[] args) {
    // Declaracion de variables tipo caracter para poder sacar el codigo ascii
    char J = 'J', j = 'j';
    
    // Imprimir por pantalla el codigo
    System.out.println((int) J);
    System.out.println((int) j);

  }

}
