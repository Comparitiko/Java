/*
  3. Expresar las siguientes expresiones como condiciones lógicas.
    a. a es mayor que 2 => a > 2
    b. b es menor o igual que 25 pero mayor que 5 => b <= 25 && b > 5
    c. c es mayor que 6 o igual a d => c > 6 || c == d
    d. e es par menor que 50 => e < 50 && e % 2 == 0
    e. f es mayor que a, b y c => f > a && f > b && f > c 
    f. g es igual a 3, 4 ó 5 => g == 3 || g == 4 || g == 5
 */
