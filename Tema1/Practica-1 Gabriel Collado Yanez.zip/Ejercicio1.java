/*
 1. Si A = 6, B = 2, C = 3, indicar el resultado final de las siguientes expresiones aritméticas:
    a. (A * C) % C => resultado = 0
    b. A * B / C => resultado = 4
    c. C % B + C * B => resultado = 7
    d. A % ( A * B * C / (B + C) ) => resultado = 7.2
    e. B * B + C – B * (A % B) => resultado = 7
 */