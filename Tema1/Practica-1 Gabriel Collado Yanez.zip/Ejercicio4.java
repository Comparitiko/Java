/*
  4. Decir si son verdaderas o falsas las siguientes expresiones:
    a. (3 <= 7) && (7 <= 7) => true
    b. !((–8 > 1) && (3 <= 4)) => true
    c. “Hola” == “Hola ” => false
    d. ((2 <= 5) && (3 >= 6)) || (2 > –1) => true
    e. ((2 <= 5) || (3 >= 6)) && (2 > –1) => true
 */
