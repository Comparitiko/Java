/*
 2. ¿Cuáles son los valores de a y b después de ejecutar las siguientes instrucciones?
    a = 3;
    b = 4;
    c = 2 * a * b;
    a = a + 2;
    b = c – a;

    a => 5 
    b => 19
 */