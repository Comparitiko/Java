/*
  9. El siguiente programa tiene 3 fallos, averigua cuáles son y modifica el programa para que funcione.
    class Cuadrado {
      public static void main(String [] args) {
        int numero=2,
        cuad=numero * número;
        System.out.println("EL CUADRADO DE "+NUMERO+" ES: " + cuad);
      }
    }
 */


public class Ejercicio9 {
  public static void main(String[] args) {
    int numero=2,
    cuad = numero * numero;
    System.out.println("EL CUADRADO DE "+ numero + " ES: " + cuad);
  }
}
